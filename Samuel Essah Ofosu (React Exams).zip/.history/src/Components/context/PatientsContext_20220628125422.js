
import React from 'react';

const PatientsContext = React.createContext();

export default PatientsContext;